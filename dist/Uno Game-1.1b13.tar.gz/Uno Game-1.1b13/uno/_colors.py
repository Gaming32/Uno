from ._color import *

RED = Color('r', 'red', 1)
GREEN = Color('g', 'green', 2)
BLUE = Color('b', 'blue', 4)
YELLOW = Color('y', 'yellow', 3)
WILD = Color('w', 'wild', 5)

# __all__ = dir()