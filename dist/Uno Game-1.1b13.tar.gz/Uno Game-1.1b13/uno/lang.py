questions = {
    'wild': "What would you like to change the color to? ",
    'call wild': "The last player played a Draw Four Wild. Would you like to call? "
}
