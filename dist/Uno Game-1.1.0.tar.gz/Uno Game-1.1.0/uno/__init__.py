from ._init import *

__version__ = '1.1.0'
__author__ = 'Gaming32'

if __name__ == '__main__':
    from .main import *
    main()