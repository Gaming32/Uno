try: from .main import *
except ImportError: from uno.main import *
main()